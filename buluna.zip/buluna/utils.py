from __future__ import division, print_function
import argparse
import collections
import functools
import os
import boto3
import sys
import threading
import configparser
import pandas as pd
import numpy
import time
from boto3.s3 import transfer
from concurrent import futures
import signal
import threading
import asyncio
import concurrent.futures
from traceback import print_exc
import logging
import datetime
import uuid
import re
from threading import BoundedSemaphore
import cryptography
from cryptography.fernet import Fernet

class LockOb(object):
    def __init__(self):
        self.m_lock= threading.Lock()
        self.m_cancel=False
class BoundedExecutor:    
    def __init__(self, max_workers):
        self.executor = concurrent.futures.ThreadPoolExecutor(max_workers=max_workers)
        self.semaphore = BoundedSemaphore(max_workers)
    def submit(self, fn, *args, **kwargs):        
        self.semaphore.acquire()        
        try:
            future = self.executor.submit(fn, *args, **kwargs)
        except:            
            self.semaphore.release()
            raise
        else:            
            future.add_done_callback(lambda x: self.semaphore.release())
            return future
        finally:
            pass    
    def shutdown(self, wait=True):
        self.executor.shutdown(wait)


class AppConfigObject(object):
    def __init__(self):
        fconfig = configparser.ConfigParser()
        fconfig.read('app.config')
        self.logfolder=fconfig.get('Logs', 'LogFolder') 
        self.rptfolder=fconfig.get('Logs', 'RptFolder') 
        self.metafolder=fconfig.get('Logs', 'ProcessLog')
        self.configFolder= fconfig.get('App', 'ConfigFolder')        
        self.encKey = self.getEncKey(fconfig.get("App", "EncFile"))
    def getEncKey(self, aEncFile):
        fEncKey=None
        with open(aEncFile, "r") as text_file:
             fEncKey= text_file.read()
        return fEncKey
class ConfigObject(object):
    def __init__(self,aConfigFile,aEncKey=""):
        config = configparser.ConfigParser()
        config.read(aConfigFile)     
        cipher_suite = Fernet(aEncKey)
        self.m_transfertype = config.get('App', 'TransferType')
        self.m_awsAccKey =""
        self.m_awsSecKey =""        
        try:
            self.m_awsAccKey = cipher_suite.decrypt(str.encode(config.get('TransferInfo', 'AccessKey'))).decode("utf-8") 
            self.m_awsSecKey = cipher_suite.decrypt(str.encode(config.get('TransferInfo', 'SecretKey'))).decode("utf-8") 
        except:
            msg='Check the Encrypt Key'
            logger.error(msg)
            raise Exception()
        self.m_srcbucket = config.get('TransferInfo', 'SrcBucket')
        self.m_srcPrefix = config.get('TransferInfo', 'SrcPrefix')
        self.m_destbucket = config.get('TransferInfo', 'DestBucket')
        self.m_destPrefix = config.get('TransferInfo', 'DestPrefix')
        self.m_localfolders = config.get('TransferInfo', 'DestFolder')
        self.m_foldertoupload= config.get('TransferInfo', 'SrcFolder')
        self.m_numthreads = config.getint('TransferInfo', 'NumThreads')
        self.m_rptlocation = config.get('TransferInfo', 'RptLocation')
        self.m_ufilename=""
        self.m_opsmode="dwl"
        self.m_uuid=""
        strpattern=config.get('TransferInfo', 'FilePattern')
        arrpattern=strpattern.split(",")        
        self.regpattern= "(" + ")|(".join(arrpattern) + ")"
        self.flagFile= config.get('TransferInfo', 'FlagFileName')
        
    def as_dict(self):
            return {'srcbucket': self.m_srcbucket, 'srckey': self.m_srckey,'destbucket': self.m_destbucket, 'destkey': self.m_destkey,
                    'srcfilesize': self.m_SrcFileSize, 'destfilesize': self.m_DestFileSize,
                    's3resId': self.m_s3resId, 'status': self.m_status
                    }                    
    @staticmethod
    def GetConfigInfo(aDict):
        fConfigObject= ConfigObject()
        fConfigObject.m_awsAccKey = aDict['AccessKey']
        fConfigObject.m_awsSecKey = aDict['SecretKey']
        fConfigObject.m_srcbucket = aDict['SrcBucket']
        fConfigObject.m_srcPrefix = aDict['SrcPrefix']
        fConfigObject.m_destbucket = aDict['DestBucket']
        fConfigObject.m_destPrefix = aDict['DestPrefix']
        fConfigObject.m_region = aDict['Region']
        fConfigObject.m_localfolders = aDict['LocalFolders']
        fConfigObject.m_foldertoupload= aDict['FoldertoUpload']
        fConfigObject.m_numthreads = aDict['FoldertoUpload'] 
        fConfigObject.m_ufilename=""
        fConfigObject.m_opsmode="dwl"
        return fConfigObject

class s3SupportObject(object):
    def __init__(self,aConfigObject):
        self.m_arrs3clientres=[]
        self.m_arrs3Client=[]        
        self.buildsupportingObjects(aConfigObject)

    def buildsupportingObjects(self,aConfigObject):
        for x in range(0, aConfigObject.m_numthreads):
            s3client = boto3.client('s3', aws_access_key_id=aConfigObject.m_awsAccKey,aws_secret_access_key=aConfigObject.m_awsSecKey)
            session = boto3.Session(aws_access_key_id=aConfigObject.m_awsAccKey,aws_secret_access_key=aConfigObject.m_awsSecKey)
            s3_resource = session.resource("s3")
            self.m_arrs3clientres.append(s3_resource)
            self.m_arrs3Client.append(s3client)
class TransferInfo:
    def __init__(self,aSrBucket,aSrcKey,aDestBucket,aDestKey,aS3ResId):
        self.Id=0
        self.m_srcbucket = aSrBucket
        self.m_srckey = aSrcKey
        self.m_destbucket = aDestBucket
        self.m_destkey = aDestKey
        self.m_s3resId =aS3ResId
        self.m_SrcFileSize=0
        self.m_DestFileSize=0
        self.m_status=0
    def as_dict(self):
        return {'srcbucket': self.m_srcbucket, 'srckey': self.m_srckey,'destbucket': self.m_destbucket, 'destkey': self.m_destkey,'srcfilesize': self.m_SrcFileSize, 'destfilesize': self.m_DestFileSize}
    def as_dict_v2(self):
            return {'id':self.Id , 'srcbucket': self.m_srcbucket, 'srckey': self.m_srckey,'destbucket': self.m_destbucket, 'destkey': self.m_destkey,
                    'srcfilesize': self.m_SrcFileSize, 'destfilesize': self.m_DestFileSize,
                    's3resId': self.m_s3resId, 'status': self.m_status
                    }                    
    @staticmethod
    def GetTransInfo(aDict):
        fTransInfo= TransferInfo(aDict['srcbucket'],aDict['srckey'],aDict['destbucket'],aDict['destkey'],aDict['s3resId'])
        fTransInfo.Id= aDict['id']
        fTransInfo.m_SrcFileSize =aDict['srcfilesize']
        fTransInfo.m_DestFileSize =aDict['destfilesize']
        fTransInfo.m_status =aDict['status']
        return fTransInfo
    def __eq__(self, other):
        return self.Id == other.Id
