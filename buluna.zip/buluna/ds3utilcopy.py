''' s3Copy Util Ganesh Sankarasubramanian 05/01/2020 
1.	To download from S3 to Local  Execute the s3utilcopy and pass the configuration file and mode( 0 for download from S3 to Local)
	e.g   python s3utilcopy.py --ConfigFile=cdwdownloadconfig.ini 
        

2.	To upload from local server to S3 Execute the s3utilcopy.py and pass the configuration file and mode( 1 for upload from local to S3 )
		e.g python s3utilcopy.py --ConfigFile=uploadconfig.ini 
        
3.	To copy between s3 buckets 
	Execute the s3utilcopy.py and pass the configuration file and mode( 2 for Copy between two S3 buckets)
    e.g python s3utilcopy.py --ConfigFile=copyconfig.ini 

'''
from __future__ import division, print_function
import argparse
import collections
import functools
import os
import sys
import numpy
import re
import configparser
import time
import asyncio
from traceback import print_exc
import logging
import datetime
import uuid
import re
import datetime

import cryptography
from cryptography.fernet import Fernet
from utils import LockOb,BoundedExecutor,AppConfigObject,ConfigObject,s3SupportObject,TransferInfo
from configvalidator import ConfigValidator
from ps3factory import PS3Factory
from parallelbaseexecutor import ParallelBaseExecutor
from paralleldownexecutor import ParallelDownExecutor
from parallelupexecutor import ParallelUpExecutor
from parallels3copyexecutor import ParallelS3CopyExecutor


def logduration(aEndTime, aStTime):
    fduration = aEndTime - aStTime
    fduration_in_s = fduration.total_seconds()  
    fdays    = divmod(fduration_in_s, 86400)        
    fhours   = divmod(fdays[1], 3600)               
    fminutes = divmod(fhours[1], 60)                
    fseconds = divmod(fminutes[1], 1)               
    if logger!=None:
        logger.info("The duration of the process: %d hours, %d minutes and %d seconds" % (fhours[0], fminutes[0], fseconds[0]))
def Init(aUID,aConfigObject,aConfigFile):    
    fconfigfolder=aConfigObject.configFolder 
    fConfigFile= os.path.join(fconfigfolder, aConfigFile)    
    fconfig = configparser.ConfigParser()
    fconfig.read(fConfigFile)
    utc_datetime="{}".format(datetime.datetime.utcnow().strftime("%Y-%m-%d-%H%MZ"))
    logfilename=os.path.join(aConfigObject.logfolder, "log_{}_{}.txt".format(utc_datetime,aUID))
    flogger = logging.getLogger('S3UtilLogger')
    flogger.setLevel(logging.INFO)
    fh = logging.FileHandler(logfilename)
    fh.setLevel(logging.INFO)
    ch = logging.StreamHandler()
    ch.setLevel(logging.INFO)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s -%(relativeCreated)6d - %(message)s')
    ch.setFormatter(formatter)
    fh.setFormatter(formatter)    
    flogger.addHandler(ch)
    flogger.addHandler(fh)
    return flogger
    
async def ExecuteMain(appConfig,aArgs,aUUID, aRefId=-1):
    fParallelBaseExec=None
    try:        
        fconfigfolder=appConfig.configFolder
        fConfigFile= os.path.join(fconfigfolder, args.ConfigFile)
        fConfigObject=ConfigObject(fConfigFile,appConfig.encKey)
        fConfigObject.m_uuid=aUUID
        fLockOb = LockOb()
        logger.info("Executing Factory")
        fParallelBaseExec=PS3Factory.GetExecutor(appConfig,fConfigObject)    
        fParallelBaseExec.m_lockobj=fLockOb        
        if (args.RefId!="-1"):
            logger.info("Restoring the Processlog for restore")
            fParallelBaseExec.LoadWorkLoad(args.RefId)
        else:
            logger.info("Preparing the Process Log ")
            fParallelBaseExec.preparefilelist()
            logger.info("Exporting Process Log ")
            fParallelBaseExec.ExportWorkLoad()
        logger.info("Executing multithreaded processsing")
        await fParallelBaseExec.ExecuteParallel()
        fParallelBaseExec.postprocess()        
        
    except KeyboardInterrupt:
        logger.error("captured ctrl cancel from ExecuteMain")
        with fLockOb.m_lock:
            fLockOb.m_cancel=True
        raise
    except: 
        logger.error("error occurred ExecuteMain")
        logger.error(print_exc(),exc_info=1)
        raise
    finally:
        if (fParallelBaseExec!=None):
            fParallelBaseExec.MarkATaskCompleted(None,-1)

if __name__ == "__main__":
    print("start")
    parser = argparse.ArgumentParser()
    print("after arg parser")
    parser.add_argument('--ConfigFile', help='Configuration Ini file' , required=True)    
    parser.add_argument('--RefId', help='Unique Id for the Restoring',default='-1' )
    args = parser.parse_args()    
    sttime = datetime.datetime.now()        
    logger=None
    fAppConfig=None
    fUID= str(uuid.uuid1())
    fExitCode = 0
    print("before AppConfigObject")
    
    

    try:
        fAppConfig = AppConfigObject()
        start = time.process_time()        
        print("Before Init")
        logger=Init(fUID,fAppConfig,args.ConfigFile)
        logger.info(args)        
        logger.info("configFile-->"+ args.ConfigFile)        
        logger.info("Unique Id for the Run : "+ fUID)
        logger.info("Start Time "+time.strftime('%X %x %Z') )        
        logger.info("Configuration Validation Steps Starts")
        print("Before ConfigValidator")
        fConfigValidator= ConfigValidator(args,fAppConfig)
        fConfigValidator.Validate()        
        logger.info("Configuration Validation Completed")
        print("Before ExecuteMain")
        asyncio.run(ExecuteMain(fAppConfig,args,fUID))
        

    except KeyboardInterrupt:
        fExitCode=1
        logger.error("captured ctrl cancel from Main")
    except: 
        print_exc()
        fExitCode=1
        if logger!=None:
            logger.error("error occurred")
            logger.error(print_exc(),exc_info=1)
    finally:                
        if fExitCode!=0:
            print("The application is exiting with exception ")
            if logger!=None:
                logger.info("The application is exiting with exception ")
        logduration(datetime.datetime.now(), sttime)
        if logger!=None:
            logger.info("End Time "+time.strftime('%X %x %Z'))
        sys.exit(fExitCode)
