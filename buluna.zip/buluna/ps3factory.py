from utils import AppConfigObject,ConfigObject,s3SupportObject
from parallelbaseexecutor import ParallelBaseExecutor
from paralleldownexecutor import ParallelDownExecutor
from parallelupexecutor import ParallelUpExecutor
from parallels3copyexecutor import ParallelS3CopyExecutor
class PS3Factory:
    @staticmethod
    def GetExecutor(aPPConfig,aConfigObject):
        fParallelExec=None
        #S3_2_S3 # S3_2_Server  , Server_2_S3
        if (aConfigObject.m_transfertype=="S3_2_Server"):
            fParallelExec=ParallelDownExecutor(aConfigObject,aPPConfig)
        elif (aConfigObject.m_transfertype=="Server_2_S3"):
            fParallelExec=ParallelUpExecutor(aConfigObject,aPPConfig)
        elif (aConfigObject.m_transfertype=="S3_2_S3"):
            fParallelExec=ParallelS3CopyExecutor(aConfigObject,aPPConfig)
        return fParallelExec