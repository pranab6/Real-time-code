from __future__ import division, print_function
import argparse
import cryptography
from cryptography.fernet import Fernet
import configparser

class Crypto2(object):
    def __init__(self):
        pass
    def GenerateKey(self):
        fKey = Fernet.generate_key()    
        return fKey
    def Encrypt(self,aStrtoEncrpt, aKey):        
        fcipherst = Fernet(aKey)
        return fcipherst.encrypt(str.encode(aStrtoEncrpt))
    def Decrypt(self,aStrtoDecrypt,aKey):
        fcipherst = Fernet(aKey)
        #return fcipherst.decrypt(aStrtoDecrypt).decode("utf-8")
        plain_text = fcipherst.decrypt(str.encode(aStrtoDecrypt)).decode("utf-8")
        return plain_text
        

if __name__ == "__main__":
    #python crypto.py --Mode=Key 
    #python crypto.py --Mode=Encrypt --Key=n19VOehihrxPqgPWThTJs7hiixs372V0FlKlkmHVYos= --StrEncDec=AWSKEY
    #python crypto.py --Mode=Decrypt --Key=n19VOehihrxPqgPWThTJs7hiixs372V0FlKlkmHVYos= --StrEncDec=gAAAAABexukXHHyIzwM0jjoeK64lyLqmFiYyi6ob0yWyQj1f_1okeeQ751ABLUDFeAZ-uBqltYQVKZV_eTYzliLBBDymsBtzQg==
    
    parser = argparse.ArgumentParser()
    parser.add_argument('--Mode', help='Key, Encrypt Decrypt' , required=True)
    parser.add_argument('--Key', help='Key is Required for Encrypt Decrypt',default='' )
    parser.add_argument('--StrEncDec', help='Key is Required for Encrypt Decrypt',default='' )
    args = parser.parse_args()    
        
    fCrypto= Crypto2()
    try:        
        if args.Mode=="Key":
            fKey= fCrypto.GenerateKey()
            print(fKey)
        elif args.Mode=="Encrypt":
            
            fEncrypted=fCrypto.Encrypt(args.StrEncDec, args.Key)
            print(fEncrypted)
        elif args.Mode=="Decrypt":
            fDecrypted= fCrypto.Decrypt(args.StrEncDec, args.Key)
            print(fDecrypted)
    except:
        print("error occurred")
        print(print_exc(),exc_info=1)