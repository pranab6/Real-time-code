import boto3
from boto3.s3 import transfer
from utils import AppConfigObject,ConfigObject,s3SupportObject,TransferInfo
from parallelbaseexecutor import ParallelBaseExecutor
import logging
import re
import os

class ParallelUpExecutor(ParallelBaseExecutor):
    def preparefilelist(self):
        dicFiles={}
        self.m_logger.info("Preparing the List of Upload Files ")
        rowId=1    
        fNetworkPath= self.m_ConfigObject.m_foldertoupload
        #print("folder to upload" + fNetworkPath )
        strreplace=""
        if os.name=='nt':
            strreplace=fNetworkPath+"\\"
        else:
           strreplace=fNetworkPath 
        for root, dirs, files in os.walk(fNetworkPath, topdown=False):        
            for name in files:
                if self.MatchPattern(name):    
                    fs3Client=rowId%self.m_ConfigObject.m_numthreads
                    rowId=rowId+1   
                    fFile = os.path.join(root, name)
                    keyfileName=fFile.replace(strreplace,"").replace("\\","/")  
                    if  os.name!='nt':
                        keyfileName=re.sub("\/","",keyfileName,count=1)
                    fS3file= self.m_ConfigObject.m_destPrefix+ "/"+ keyfileName
                    dupkeyCheck="{}".format(fFile)
                    if not dupkeyCheck in dicFiles:
                        fTransInfo = TransferInfo("",fFile, self.m_ConfigObject.m_destbucket, fS3file,fs3Client)
                        fTransInfo.Id=rowId
                        dicFiles[dupkeyCheck]=1
                        self.m_arrTransferInfo.append(fTransInfo)
        return self.m_arrTransferInfo
        
    def Execute(self,aTransferInfo):     
        try:
            if (aTransferInfo.m_status==0):
                fS3Client= self.ms3SupportObject.m_arrs3Client[aTransferInfo.m_s3resId]
                tconfig=transfer.TransferConfig(multipart_threshold=5*1024*1024, max_concurrency=5,multipart_chunksize=5*1024*1024, use_threads=True)
                self.m_logger.info("uploading "+ aTransferInfo.m_srckey  + " Started")
                fuploadeder = transfer.S3Transfer(fS3Client,tconfig, transfer.OSUtils())
                aTransferInfo.m_SrcFileSize= os.path.getsize(aTransferInfo.m_srckey)
                fuploadeder.upload_file(aTransferInfo.m_srckey,aTransferInfo.m_destbucket,aTransferInfo.m_destkey)
                self.m_logger.info("uploading "+ aTransferInfo.m_srckey  + " completed ")            
                fObject = self.ms3SupportObject.m_arrs3clientres[0].Object(aTransferInfo.m_destbucket,aTransferInfo.m_destkey)
                aTransferInfo.m_DestFileSize = fObject.content_length
                aTransferInfo.m_status=1
                self.MarkATaskCompleted(None,aTransferInfo.Id)
        except KeyboardInterrupt:
            self.m_logger.error("captured ctrl cancel from Execute Method")
            raise
        except:
            self.m_logger.error("Error occurred during upload")
            self.m_logger.error(print_exc(),exc_info=1)
            print(sys.exc_info()[0](traceback.format_exc()))
            raise
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.m_logger.info('Exit from ParallelS3UpExecutor')
    def __enter__(self):
        self.m_logger.info('enter into ParallelS3UpExecutor')
        return self    