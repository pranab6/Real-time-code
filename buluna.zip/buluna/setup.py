from setuptools import setup, find_packages
with open('README.rst') as f:
    readme = f.read()

with open('LICENSE') as f:
    license = f.read()

setup(
    name='s3copyutil',
    version='0.1.0',
    description='S3 Copy Util',
    long_description=readme,
    author='IQVIA',
    author_email='',
    url='',
    license=license,
    packages=find_packages(exclude=('tests', 'docs'))
)