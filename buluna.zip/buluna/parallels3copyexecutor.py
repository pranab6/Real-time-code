import boto3
from utils import AppConfigObject,ConfigObject,s3SupportObject,TransferInfo
from parallelbaseexecutor import ParallelBaseExecutor
import logging
import re
class ParallelS3CopyExecutor(ParallelBaseExecutor):    
    def preparefilelist(self):
        dicFiles={}
        self.m_logger.info("Preparing the List of Upload Files ")
        keys = []
        dirs = []
        next_token = ''
        mPrefix = self.m_ConfigObject.m_srcPrefix  + '/'                
        base_kwargs = {'Bucket': self.m_ConfigObject.m_srcbucket, 'Prefix': self.m_ConfigObject.m_srcPrefix }
        while next_token is not None:
            kwargs = base_kwargs.copy()
            if next_token != '':
                kwargs.update({'ContinuationToken': next_token})
            results = self.ms3SupportObject.m_arrs3Client[0].list_objects_v2(**kwargs)
            contents = results.get('Contents')
            for i in contents:
                k = i.get('Key')
                if k[-1] != '/':
                    keys.append(k)
                else:
                    dirs.append(k)
            next_token = results.get('NextContinuationToken')
        cnt=1
        for k in keys:
            if self.MatchPattern(k):
                s3ClientId=cnt%self.m_ConfigObject.m_numthreads
                cnt=cnt+1
                kn = k.replace(mPrefix, '')
                destkey= self.m_ConfigObject.m_destPrefix  + "/"+kn
                dupkeyCheck="{}_{}".format(self.m_ConfigObject.m_srcbucket, k)
                if not dupkeyCheck in dicFiles:
                    dicFiles[dupkeyCheck]=1
                    fTransInfo= TransferInfo(self.m_ConfigObject.m_srcbucket, k, self.m_ConfigObject.m_destbucket,destkey,s3ClientId)            
                    self.m_arrTransferInfo.append(fTransInfo)
        return self.m_arrTransferInfo
        
        
    def Execute(self,aTransferInfo):        
        try:
            if (aTransferInfo.m_status==0):
                self.m_logger.info("Copying File"+aTransferInfo.m_srckey+ " Started")
                copy_source = {'Bucket': aTransferInfo.m_srcbucket,'Key': aTransferInfo.m_srckey}
                fS3ClientRes= self.ms3SupportObject.m_arrs3clientres[aTransferInfo.m_s3resId]
                fS3ClientRes.meta.client.copy(copy_source, aTransferInfo.m_destbucket, aTransferInfo.m_destkey)
                fObject1 = self.ms3SupportObject.m_arrs3clientres[0].Object(aTransferInfo.m_srcbucket,aTransferInfo.m_srckey)
                aTransferInfo.m_SrcFileSize = fObject1.content_length
                self.m_logger.info("Copying File"+aTransferInfo.m_srckey+ " Completed")
                fObject2 = self.ms3SupportObject.m_arrs3clientres[0].Object(aTransferInfo.m_destbucket,aTransferInfo.m_destkey)
                aTransferInfo.m_DestFileSize = fObject2.content_length
                aTransferInfo.m_status=1
                self.MarkATaskCompleted(None,aTransferInfo.Id)
        except KeyboardInterrupt:
            self.m_logger.error("captured ctrl cancel from Execute Method")
            raise
        except: 
            self.m_logger.error("Error occurred during Copy")
            self.m_logger.error(print_exc(),exc_info=1)
            raise        
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.m_logger.info('Exit from ParallelS3CopyExecutor')
    def __enter__(self):
        self.m_logger.info('enter into ParallelS3CopyExecutor')
        return self    