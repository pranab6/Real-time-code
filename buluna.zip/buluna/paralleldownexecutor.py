import boto3
from boto3.s3 import transfer
from utils import AppConfigObject,ConfigObject,s3SupportObject,TransferInfo
import logging
import re
import os
from parallelbaseexecutor import ParallelBaseExecutor
class ParallelDownExecutor(ParallelBaseExecutor):
    def preparefilelist(self):
        dicFiles={}
        arrPrefix=self.m_ConfigObject.m_srcPrefix.split(",")
        for fPrefix in arrPrefix:
            keys = []
            dirs = []
            next_token = ''
            fPrefix=fPrefix+ '/'            
            base_kwargs = {'Bucket': self.m_ConfigObject.m_srcbucket, 'Prefix': fPrefix}
            while next_token is not None:
                kwargs = base_kwargs.copy()
                if next_token != '':
                    kwargs.update({'ContinuationToken': next_token})
                results = self.ms3SupportObject.m_arrs3Client[0].list_objects_v2(**kwargs)
                contents = results.get('Contents')
                for i in contents:
                    k = i.get('Key')
                    if k[-1] != '/':
                        keys.append(k)
                    else:
                        dirs.append(k)
                next_token = results.get('NextContinuationToken')

            for d in dirs:
                dn = d.replace(fPrefix, '')
                dest_pathname = os.path.join(self.m_ConfigObject.m_localfolders, dn)
                if not os.path.exists(os.path.dirname(dest_pathname)):
                    os.makedirs(os.path.dirname(dest_pathname))    
            rowId=1        
            for k in keys:
                if self.MatchPattern(k):
                    s3ClientId=rowId%self.m_ConfigObject.m_numthreads
                    rowId=rowId+1
                    kn = k.replace(fPrefix, '')
                    dest_pathname = os.path.join(self.m_ConfigObject.m_localfolders, kn)
                    if not os.path.exists(os.path.dirname(dest_pathname)):
                        os.makedirs(os.path.dirname(dest_pathname))                    
                    dupkeyCheck="{}_{}".format(self.m_ConfigObject.m_srcbucket, k)
                    if not dupkeyCheck in dicFiles:
                        fTransInfo = TransferInfo(self.m_ConfigObject.m_srcbucket, k,"", dest_pathname,s3ClientId)
                        fTransInfo.Id=rowId
                        dicFiles[dupkeyCheck]=1
                        self.m_arrTransferInfo.append(fTransInfo)
        return self.m_arrTransferInfo
    def Execute(self,aTransferInfo):
        try:
            if (aTransferInfo.m_status==0):
                fS3Client= self.ms3SupportObject.m_arrs3Client[aTransferInfo.m_s3resId]
                self.m_logger.info("downloading "+ aTransferInfo.m_srckey  + " Started")
                fObject = self.ms3SupportObject.m_arrs3clientres[0].Object(aTransferInfo.m_srcbucket,aTransferInfo.m_srckey)
                aTransferInfo.m_SrcFileSize = fObject.content_length
                downloader = transfer.S3Transfer(fS3Client,transfer.TransferConfig(), transfer.OSUtils())
                downloader.download_file(aTransferInfo.m_srcbucket,aTransferInfo.m_srckey,aTransferInfo.m_destkey)
                self.m_logger.info("downloading "+ aTransferInfo.m_srckey + " Completed")
                aTransferInfo.m_DestFileSize= os.path.getsize(aTransferInfo.m_destkey)
                aTransferInfo.m_status=1
                self.MarkATaskCompleted(None,aTransferInfo.Id)
        except KeyboardInterrupt:
            self.m_logger.error("captured ctrl cancel from Execute Method")
            raise
        except:
            self.m_logger.error("Error occurred during download")
            self.m_logger.error(print_exc(),exc_info=1)
            raise
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.m_logger.info('Exit from ParallelDownExecutor')
        self.finalize()

    def __enter__(self):
        self.m_logger.info('enter into ParallelDownExecutor')
        return self