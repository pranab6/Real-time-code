''' s3Copy Util Ganesh Sankarasubramanian 05/01/2020 
1.	To download from S3 to Local  Execute the s3utilcopy and pass the configuration file and mode( 0 for download from S3 to Local)
	e.g   python s3utilcopy.py --ConfigFile=cdwdownloadconfig.ini 
        

2.	To upload from local server to S3 Execute the s3utilcopy.py and pass the configuration file and mode( 1 for upload from local to S3 )
		e.g python s3utilcopy.py --ConfigFile=uploadconfig.ini 
        
3.	To copy between s3 buckets 
	Execute the s3utilcopy.py and pass the configuration file and mode( 2 for Copy between two S3 buckets)
    e.g python s3utilcopy.py --ConfigFile=copyconfig.ini 

'''
from __future__ import division, print_function
import argparse
import collections
import functools
import os
import boto3
import sys
import threading
import configparser
import pandas as pd
import numpy
import time
from boto3.s3 import transfer
from concurrent import futures
import signal
import threading
import asyncio
import concurrent.futures
from traceback import print_exc
import logging
import datetime
import uuid
import re
from threading import BoundedSemaphore
import cryptography
from cryptography.fernet import Fernet

class LockOb(object):
    def __init__(self):
        self.m_lock= threading.Lock()
        self.m_cancel=False
class BoundedExecutor:    
    def __init__(self, max_workers):
        self.executor = concurrent.futures.ThreadPoolExecutor(max_workers=max_workers)
        self.semaphore = BoundedSemaphore(max_workers)
    def submit(self, fn, *args, **kwargs):        
        self.semaphore.acquire()        
        try:
            future = self.executor.submit(fn, *args, **kwargs)
        except:            
            self.semaphore.release()
            raise
        else:            
            future.add_done_callback(lambda x: self.semaphore.release())
            return future
        finally:
            pass    
    def shutdown(self, wait=True):
        self.executor.shutdown(wait)


class AppConfigObject(object):
    def __init__(self):
        fconfig = configparser.ConfigParser()
        fconfig.read('App.config')
        self.logfolder=fconfig.get('Logs', 'LogFolder') 
        self.rptfolder=fconfig.get('Logs', 'RptFolder') 
        self.metafolder=fconfig.get('Logs', 'ProcessLog')
        self.configFolder= fconfig.get('App', 'ConfigFolder')
        self.encKey=fconfig.get("App","EncKey")
        
class ConfigObject(object):
    def __init__(self,aConfigFile,aEncKey=""):
        config = configparser.ConfigParser()
        config.read(aConfigFile)     
        cipher_suite = Fernet(aEncKey)
        self.m_transfertype = config.get('App', 'TransferType')
        self.m_awsAccKey =""
        self.m_awsSecKey =""        
        try:
            self.m_awsAccKey = cipher_suite.decrypt(str.encode(config.get('TransferInfo', 'AccessKey'))).decode("utf-8") 
            self.m_awsSecKey = cipher_suite.decrypt(str.encode(config.get('TransferInfo', 'SecretKey'))).decode("utf-8") 
        except:
            msg='Check the Encrypt Key'
            logger.error(msg)
            raise Exception()
        self.m_srcbucket = config.get('TransferInfo', 'SrcBucket')
        self.m_srcPrefix = config.get('TransferInfo', 'SrcPrefix')
        self.m_destbucket = config.get('TransferInfo', 'DestBucket')
        self.m_destPrefix = config.get('TransferInfo', 'DestPrefix')
        self.m_localfolders = config.get('TransferInfo', 'DestFolder')
        self.m_foldertoupload= config.get('TransferInfo', 'SrcFolder')
        self.m_numthreads = config.getint('TransferInfo', 'NumThreads')
        self.m_rptlocation = config.get('TransferInfo', 'RptLocation')
        self.m_ufilename=""
        self.m_opsmode="dwl"
        self.m_uuid=""
        strpattern=config.get('TransferInfo', 'FilePattern')
        arrpattern=strpattern.split(",")        
        self.regpattern= "(" + ")|(".join(arrpattern) + ")"
        #self.flagFile= os.path.join(config.get('FILES', 'FlagFolder'),config.get('FILES', 'FlagFileName'))
        
    def as_dict(self):
            return {'srcbucket': self.m_srcbucket, 'srckey': self.m_srckey,'destbucket': self.m_destbucket, 'destkey': self.m_destkey,
                    'srcfilesize': self.m_SrcFileSize, 'destfilesize': self.m_DestFileSize,
                    's3resId': self.m_s3resId, 'status': self.m_status
                    }                    
    @staticmethod
    def GetConfigInfo(aDict):
        fConfigObject= ConfigObject()
        fConfigObject.m_awsAccKey = aDict['AccessKey']
        fConfigObject.m_awsSecKey = aDict['SecretKey']
        fConfigObject.m_srcbucket = aDict['SrcBucket']
        fConfigObject.m_srcPrefix = aDict['SrcPrefix']
        fConfigObject.m_destbucket = aDict['DestBucket']
        fConfigObject.m_destPrefix = aDict['DestPrefix']
        fConfigObject.m_region = aDict['Region']
        fConfigObject.m_localfolders = aDict['LocalFolders']
        fConfigObject.m_foldertoupload= aDict['FoldertoUpload']
        fConfigObject.m_numthreads = aDict['FoldertoUpload'] 
        fConfigObject.m_ufilename=""
        fConfigObject.m_opsmode="dwl"
        return fConfigObject

class s3SupportObject(object):
    def __init__(self,aConfigObject):
        self.m_arrs3clientres=[]
        self.m_arrs3Client=[]        
        self.buildsupportingObjects(aConfigObject)

    def buildsupportingObjects(self,aConfigObject):
        for x in range(0, aConfigObject.m_numthreads):
            s3client = boto3.client('s3', aws_access_key_id=aConfigObject.m_awsAccKey,aws_secret_access_key=aConfigObject.m_awsSecKey)
            session = boto3.Session(aws_access_key_id=aConfigObject.m_awsAccKey,aws_secret_access_key=aConfigObject.m_awsSecKey)
            s3_resource = session.resource("s3")
            self.m_arrs3clientres.append(s3_resource)
            self.m_arrs3Client.append(s3client)
class TransferInfo:
    def __init__(self,aSrBucket,aSrcKey,aDestBucket,aDestKey,aS3ResId):
        self.Id=0
        self.m_srcbucket = aSrBucket
        self.m_srckey = aSrcKey
        self.m_destbucket = aDestBucket
        self.m_destkey = aDestKey
        self.m_s3resId =aS3ResId
        self.m_SrcFileSize=0
        self.m_DestFileSize=0
        self.m_status=0
    def as_dict(self):
        return {'srcbucket': self.m_srcbucket, 'srckey': self.m_srckey,'destbucket': self.m_destbucket, 'destkey': self.m_destkey,'srcfilesize': self.m_SrcFileSize, 'destfilesize': self.m_DestFileSize}
    def as_dict_v2(self):
            return {'id':self.Id , 'srcbucket': self.m_srcbucket, 'srckey': self.m_srckey,'destbucket': self.m_destbucket, 'destkey': self.m_destkey,
                    'srcfilesize': self.m_SrcFileSize, 'destfilesize': self.m_DestFileSize,
                    's3resId': self.m_s3resId, 'status': self.m_status
                    }                    
    @staticmethod
    def GetTransInfo(aDict):
        fTransInfo= TransferInfo(aDict['srcbucket'],aDict['srckey'],aDict['destbucket'],aDict['destkey'],aDict['s3resId'])
        fTransInfo.Id= aDict['id']
        fTransInfo.m_SrcFileSize =aDict['srcfilesize']
        fTransInfo.m_DestFileSize =aDict['destfilesize']
        fTransInfo.m_status =aDict['status']
        return fTransInfo
    def __eq__(self, other):
        return self.Id == other.Id
    
    
        

class ParallelBaseExecutor:
    def __init__(self,aConfigObject,aAppConfigObject):
        self.m_appConfigObject=aAppConfigObject 
        self.m_ConfigObject=aConfigObject
        self.m_arrTransferInfo=[]
        self.ms3SupportObject= s3SupportObject(aConfigObject)
        self.m_lockobj=None
    def ExportWorkLoad(self,arrayWorkLoad=None):
        if (arrayWorkLoad==None):
           arrayWorkLoad=self.m_arrTransferInfo
        df1 = pd.DataFrame([x.as_dict_v2() for x in self.m_arrTransferInfo])        
        exportfilename=os.path.join(self.m_appConfigObject.metafolder,"{}.json".format(self.m_ConfigObject.m_uuid ))
        df1.to_json(exportfilename, orient='records')

    def GetArrayWorkloadfromDict(self,aDictTrans):
        fArrTransInfofromDF=[]
        for key in aDictTrans:
            fTransInfo= TransferInfo.GetTransInfo(key)
            fArrTransInfofromDF.append(fTransInfo)
        return fArrTransInfofromDF
    def LoadWorkLoad(self,aUUID):
        wfile=os.path.join(self.m_appConfigObject.metafolder,"{}.json".format(aUUID))
        df2 = pd.read_json(wfile, orient='records')
        dicTInforecords = df2.to_dict('records')
        farrTransInfofromDF=self.GetArrayWorkloadfromDict(dicTInforecords)
        if farrTransInfofromDF!=None:
            self.m_arrTransferInfo=farrTransInfofromDF
        return 
    def UpdateTask(self,dicTInforecords,aKey):        
        fTranInfo= next((x for x in dicTInforecords if x.Id == aKey), None)
        fTranInfo.m_status=1

    def MarkATaskCompleted(self,aUUID, aKey):
        with self.m_lockobj.m_lock:
            self.ExportWorkLoad()
    def MatchPattern(self,aFileName):
        fRet=False        
        if (re.match(self.m_ConfigObject.regpattern, aFileName,re.I)!=None ):            
            return True
        return fRet
    def preparefilelist(self):
        return self.m_arrTransferInfo
    def createSuccessfile(self):        
        flagfile=os.path.join(self.m_ConfigObject.m_localfolders,self.m_ConfigObject.flagFile)
        with open(flagfile, 'w') as fp:
            logger.info("Created Flag file")
    def MoveRptandSuccessfiletoS3(self):
        pass    
    async def ExecuteParallel(self,aUUID=None):
        executor=None
        pStatus=True
        try:
            executor = BoundedExecutor(self.m_ConfigObject.m_numthreads)
            for fTransferInfo in self.m_arrTransferInfo:
                executor.submit(self.Execute, fTransferInfo)
        except KeyboardInterrupt:
            pStatus=False            
            raise
        except: 
            pStatus=False        
            raise
        finally:            
            if (executor!=None):
                executor.shutdown(pStatus)            
    
    async def ExecuteParallelB(self,aUUID=None):
        try:        
            with concurrent.futures.ThreadPoolExecutor(max_workers=self.m_ConfigObject.m_numthreads) as executor:
                future_results=[]            
                for fTransferInfo in self.m_arrTransferInfo:                
                    with self.m_lockobj.m_lock:
                        if self.m_lockobj.m_cancel==True:
                            break                    
                    future_result=executor.submit(self.Execute, fTransferInfo)
                    future_results.append(future_result)
                concurrent.futures.wait(future_results)
        except KeyboardInterrupt:
            logger.info("captured ctrl cancel from ExecuteParallel")
            with self.m_lockobj.m_lock:
                self.m_lockobj.m_cancel=True
            raise

    def Execute(self,aTransferInfo):        
        copy_source = {'Bucket': aTransferInfo.m_srcbucket,'Key': aTransferInfo.m_srckey}
        fS3ClientRes= self.ms3SupportObject.m_arrs3clientres[aTransferInfo.m_s3resId]
        fS3ClientRes.m_s3res.meta.client.copy(copy_source, aTransferInfo.m_destbucket, aTransferInfo.m_destkey)


    def postprocess(self): 
        try:        
            logger.info("Creating html report File Validation")
            fRptFolder=self.m_appConfigObject.rptfolder
            utc_datetime = datetime.datetime.utcnow()
            rptfile="qa_rpt_"+ utc_datetime.strftime("%Y-%m-%d-%H%MZ")+"_{}".format(self.m_ConfigObject.m_uuid)
            fHtmlFile=os.path.join(fRptFolder,  "{}.html".format(rptfile))
            fExcpFile=os.path.join(fRptFolder,  "{}_exception.html".format(rptfile))
            dfStats = pd.DataFrame([x.as_dict() for x in self.m_arrTransferInfo])
            totalcount= dfStats.shape[0]        
            logger.info("{}{}".format("total # of files", totalcount ))
            dfStats.to_html(open(fHtmlFile, 'w'))
            dfStatsExcp=dfStats[dfStats['srcfilesize']!=dfStats['destfilesize']]        
            excCount=dfStatsExcp.shape[0]        
            dfStatsExcp.to_html(open(fExcpFile, 'w'))
            if (excCount >0 ):
                logger.error("{}{}".format("# of files not satifying File Size Check", excCount ))
                raise Exception("{}{}".format("# of files not satifying File Size Check", excCount ))
            logger.info("Creating html report File Validation is completed successfully")
        except:
            logger.error("Error occurred during postprocess")
            logger.error(print_exc(),exc_info=1)    
        
    def __exit__(self, exc_type, exc_val, exc_tb):
        logger.info('Exit from ParallelExecutor')
        self.finalize()

    def __enter__(self):
        logger.info('enter into ParallelExecutor')
        return self

class ParallelDownExecutor(ParallelBaseExecutor):
    def preparefilelist(self):
        dicFiles={}
        arrPrefix=self.m_ConfigObject.m_srcPrefix.split(",")
        for fPrefix in arrPrefix:
            keys = []
            dirs = []
            next_token = ''
            fPrefix=fPrefix+ '/'            
            base_kwargs = {'Bucket': self.m_ConfigObject.m_srcbucket, 'Prefix': fPrefix}
            while next_token is not None:
                kwargs = base_kwargs.copy()
                if next_token != '':
                    kwargs.update({'ContinuationToken': next_token})
                results = self.ms3SupportObject.m_arrs3Client[0].list_objects_v2(**kwargs)
                contents = results.get('Contents')
                for i in contents:
                    k = i.get('Key')
                    if k[-1] != '/':
                        keys.append(k)
                    else:
                        dirs.append(k)
                next_token = results.get('NextContinuationToken')

            for d in dirs:
                dn = d.replace(fPrefix, '')
                dest_pathname = os.path.join(self.m_ConfigObject.m_localfolders, dn)
                if not os.path.exists(os.path.dirname(dest_pathname)):
                    os.makedirs(os.path.dirname(dest_pathname))    
            rowId=1        
            for k in keys:
                if self.MatchPattern(k):
                    s3ClientId=rowId%self.m_ConfigObject.m_numthreads
                    rowId=rowId+1
                    kn = k.replace(fPrefix, '')
                    dest_pathname = os.path.join(self.m_ConfigObject.m_localfolders, kn)
                    if not os.path.exists(os.path.dirname(dest_pathname)):
                        os.makedirs(os.path.dirname(dest_pathname))                    
                    dupkeyCheck="{}_{}".format(self.m_ConfigObject.m_srcbucket, k)
                    if not dupkeyCheck in dicFiles:
                        fTransInfo = TransferInfo(self.m_ConfigObject.m_srcbucket, k,"", dest_pathname,s3ClientId)
                        fTransInfo.Id=rowId
                        dicFiles[dupkeyCheck]=1
                        self.m_arrTransferInfo.append(fTransInfo)
        return self.m_arrTransferInfo
    def Execute(self,aTransferInfo):
        try:
            if (aTransferInfo.m_status==0):
                fS3Client= self.ms3SupportObject.m_arrs3Client[aTransferInfo.m_s3resId]
                logger.info("downloading "+ aTransferInfo.m_srckey  + " Started")
                fObject = self.ms3SupportObject.m_arrs3clientres[0].Object(aTransferInfo.m_srcbucket,aTransferInfo.m_srckey)
                aTransferInfo.m_SrcFileSize = fObject.content_length
                downloader = transfer.S3Transfer(fS3Client,transfer.TransferConfig(), transfer.OSUtils())
                downloader.download_file(aTransferInfo.m_srcbucket,aTransferInfo.m_srckey,aTransferInfo.m_destkey)
                logger.info("downloading "+ aTransferInfo.m_srckey + " Completed")
                aTransferInfo.m_DestFileSize= os.path.getsize(aTransferInfo.m_destkey)
                aTransferInfo.m_status=1
                self.MarkATaskCompleted(None,aTransferInfo.Id)
        except KeyboardInterrupt:
            logger.error("captured ctrl cancel from Execute Method")
            raise
        except:
            logger.error("Error occurred during download")
            logger.error(print_exc(),exc_info=1)
            raise
    def __exit__(self, exc_type, exc_val, exc_tb):
        logger.info('Exit from ParallelDownExecutor')
        self.finalize()

    def __enter__(self):
        logger.info('enter into ParallelDownExecutor')
        return self
class ParallelUpExecutor(ParallelBaseExecutor):
    def preparefilelist(self):
        dicFiles={}
        logger.info("Preparing the List of Upload Files ")
        rowId=1    
        fNetworkPath= self.m_ConfigObject.m_foldertoupload
        #print("folder to upload" + fNetworkPath )
        strreplace=""
        if os.name=='nt':
            strreplace=fNetworkPath+"\\"
        else:
           strreplace=fNetworkPath 
        for root, dirs, files in os.walk(fNetworkPath, topdown=False):        
            for name in files:
                if self.MatchPattern(name):    
                    fs3Client=rowId%self.m_ConfigObject.m_numthreads
                    rowId=rowId+1   
                    fFile = os.path.join(root, name)
                    keyfileName=fFile.replace(strreplace,"").replace("\\","/")  
                    if  os.name!='nt':
                        keyfileName=re.sub("\/","",keyfileName,count=1)
                    fS3file= self.m_ConfigObject.m_destPrefix+ "/"+ keyfileName
                    dupkeyCheck="{}".format(fFile)
                    if not dupkeyCheck in dicFiles:
                        fTransInfo = TransferInfo("",fFile, self.m_ConfigObject.m_destbucket, fS3file,fs3Client)
                        fTransInfo.Id=rowId
                        dicFiles[dupkeyCheck]=1
                        self.m_arrTransferInfo.append(fTransInfo)
        return self.m_arrTransferInfo
        
    def Execute(self,aTransferInfo):     
        try:
            if (aTransferInfo.m_status==0):
                fS3Client= self.ms3SupportObject.m_arrs3Client[aTransferInfo.m_s3resId]
                tconfig=transfer.TransferConfig(multipart_threshold=5*1024*1024, max_concurrency=5,multipart_chunksize=5*1024*1024, use_threads=True)
                logger.info("uploading "+ aTransferInfo.m_srckey  + " Started")
                fuploadeder = transfer.S3Transfer(fS3Client,tconfig, transfer.OSUtils())
                aTransferInfo.m_SrcFileSize= os.path.getsize(aTransferInfo.m_srckey)
                fuploadeder.upload_file(aTransferInfo.m_srckey,aTransferInfo.m_destbucket,aTransferInfo.m_destkey)
                logger.info("uploading "+ aTransferInfo.m_srckey  + " completed ")            
                fObject = self.ms3SupportObject.m_arrs3clientres[0].Object(aTransferInfo.m_destbucket,aTransferInfo.m_destkey)
                aTransferInfo.m_DestFileSize = fObject.content_length
                aTransferInfo.m_status=1
                self.MarkATaskCompleted(None,aTransferInfo.Id)
        except KeyboardInterrupt:
            logger.error("captured ctrl cancel from Execute Method")
            raise
        except:
            logger.error("Error occurred during upload")
            logger.error(print_exc(),exc_info=1)
            raise

class ParallelS3CopyExecutor(ParallelBaseExecutor):    
    def preparefilelist(self):
        dicFiles={}
        logger.info("Preparing the List of Upload Files ")
        keys = []
        dirs = []
        next_token = ''
        mPrefix = self.m_ConfigObject.m_srcPrefix  + '/'                
        base_kwargs = {'Bucket': self.m_ConfigObject.m_srcbucket, 'Prefix': self.m_ConfigObject.m_srcPrefix }
        while next_token is not None:
            kwargs = base_kwargs.copy()
            if next_token != '':
                kwargs.update({'ContinuationToken': next_token})
            results = self.ms3SupportObject.m_arrs3Client[0].list_objects_v2(**kwargs)
            contents = results.get('Contents')
            for i in contents:
                k = i.get('Key')
                if k[-1] != '/':
                    keys.append(k)
                else:
                    dirs.append(k)
            next_token = results.get('NextContinuationToken')
        cnt=1
        for k in keys:
            if self.MatchPattern(k):
                s3ClientId=cnt%self.m_ConfigObject.m_numthreads
                cnt=cnt+1
                kn = k.replace(mPrefix, '')
                destkey= self.m_ConfigObject.m_destPrefix  + "/"+kn
                dupkeyCheck="{}_{}".format(self.m_ConfigObject.m_srcbucket, k)
                if not dupkeyCheck in dicFiles:
                    dicFiles[dupkeyCheck]=1
                    fTransInfo= TransferInfo(self.m_ConfigObject.m_srcbucket, k, self.m_ConfigObject.m_destbucket,destkey,s3ClientId)            
                    self.m_arrTransferInfo.append(fTransInfo)
        return self.m_arrTransferInfo
        
        
    def Execute(self,aTransferInfo):        
        try:
            if (aTransferInfo.m_status==0):
                logger.info("Copying File"+aTransferInfo.m_srckey+ " Started")
                copy_source = {'Bucket': aTransferInfo.m_srcbucket,'Key': aTransferInfo.m_srckey}
                fS3ClientRes= self.ms3SupportObject.m_arrs3clientres[aTransferInfo.m_s3resId]
                fS3ClientRes.meta.client.copy(copy_source, aTransferInfo.m_destbucket, aTransferInfo.m_destkey)
                fObject1 = self.ms3SupportObject.m_arrs3clientres[0].Object(aTransferInfo.m_srcbucket,aTransferInfo.m_srckey)
                aTransferInfo.m_SrcFileSize = fObject1.content_length
                logger.info("Copying File"+aTransferInfo.m_srckey+ " Completed")
                fObject2 = self.ms3SupportObject.m_arrs3clientres[0].Object(aTransferInfo.m_destbucket,aTransferInfo.m_destkey)
                aTransferInfo.m_DestFileSize = fObject2.content_length
                aTransferInfo.m_status=1
                self.MarkATaskCompleted(None,aTransferInfo.Id)
        except KeyboardInterrupt:
            logger.error("captured ctrl cancel from Execute Method")
            raise
        except: 
            logger.error("Error occurred during Copy")
            logger.error(print_exc(),exc_info=1)
            raise        
    def __exit__(self, exc_type, exc_val, exc_tb):
        logger.info('Exit from ParallelS3CopyExecutor')
    def __enter__(self):
        logger.info('enter into ParallelS3CopyExecutor')
        return self    

class PS3Factory:
    @staticmethod
    def GetExecutor(aPPConfig,aConfigObject):
        fParallelExec=None
        #S3_2_S3 # S3_2_Server  , Server_2_S3
        if (aConfigObject.m_transfertype=="S3_2_Server"):
            fParallelExec=ParallelDownExecutor(aConfigObject,aPPConfig)
        elif (aConfigObject.m_transfertype=="Server_2_S3"):
            fParallelExec=ParallelUpExecutor(aConfigObject,aPPConfig)
        elif (aConfigObject.m_transfertype=="S3_2_S3"):
            fParallelExec=ParallelS3CopyExecutor(aConfigObject,aPPConfig)
        return fParallelExec
def Init(aUID,aConfigObject,aConfigFile):    
    fconfigfolder=aConfigObject.configFolder 
    fConfigFile= os.path.join(fconfigfolder, aConfigFile)    
    fconfig = configparser.ConfigParser()
    fconfig.read(fConfigFile)
    utc_datetime="{}".format(datetime.datetime.utcnow().strftime("%Y-%m-%d-%H%MZ"))
    logfilename=os.path.join(aConfigObject.logfolder, "log_{}_{}.txt".format(utc_datetime,aUID))
    flogger = logging.getLogger('S3 Util Logger')
    flogger.setLevel(logging.INFO)
    fh = logging.FileHandler(logfilename)
    fh.setLevel(logging.INFO)
    ch = logging.StreamHandler()
    ch.setLevel(logging.INFO)
    formatter = logging.Formatter('%(asctime)s - %(name)s - %(levelname)s -%(relativeCreated)6d - %(message)s')
    ch.setFormatter(formatter)
    fh.setFormatter(formatter)    
    flogger.addHandler(ch)
    flogger.addHandler(fh)
    return flogger
    
async def ExecuteMain(appConfig,aArgs,aUUID, aRefId=-1):
    fParallelBaseExec=None
    try:        
        fconfigfolder=appConfig.configFolder
        fConfigFile= os.path.join(fconfigfolder, args.ConfigFile)
        fConfigObject=ConfigObject(fConfigFile,appConfig.encKey)
        fConfigObject.m_uuid=aUUID
        fLockOb = LockOb()
        logger.info("Executing Factory")
        fParallelBaseExec=PS3Factory.GetExecutor(appConfig,fConfigObject)    
        fParallelBaseExec.m_lockobj=fLockOb        
        if (args.RefId!="-1"):
            logger.info("Restoring the Processlog for restore")
            fParallelBaseExec.LoadWorkLoad(args.RefId)
        else:
            logger.info("Preparing the Process Log ")
            fParallelBaseExec.preparefilelist()
            logger.info("Exporting Process Log ")
            fParallelBaseExec.ExportWorkLoad()
        logger.info("Executing multithreaded processsing")
        await fParallelBaseExec.ExecuteParallel()
        fParallelBaseExec.postprocess()        
        
    except KeyboardInterrupt:
        logger.error("captured ctrl cancel from ExecuteMain")
        with fLockOb.m_lock:
            fLockOb.m_cancel=True
        raise
    except: 
        logger.error(print_exc(),exc_info=1)
        raise
    finally:
        if (fParallelBaseExec!=None):
            fParallelBaseExec.MarkATaskCompleted(None,-1)
def ValidateS3Bucket(aS3Client,aBucket, aPrefix,aCountCheck=True):
        fcnt=0
        fkeys = []
        fnext_token = ''        
        fPrefixtmp=aPrefix.split(",")
        fPrefix=fPrefixtmp[0]
        base_kwargs = {'Bucket': aBucket, 'Prefix': fPrefix }
        while fnext_token is not None :
            kwargs = base_kwargs.copy()
            if fnext_token != '':
                kwargs.update({'ContinuationToken': fnext_token})
            results = aS3Client.list_objects_v2(**kwargs)
            contents = results.get('Contents')
            if  aCountCheck==False:
                    return 1
            for i in contents:
                k = i.get('Key')
                if k[-1] != '/':
                    fkeys.append(k)
                    fcnt+=1
                if fcnt> 0:
                    break
            fnext_token = results.get('NextContinuationToken')
        return fcnt

def ValidateFileSystem(aConfigObject):
    fs3client=None
    try:       
        fs3client = boto3.client('s3', aws_access_key_id=aConfigObject.m_awsAccKey,aws_secret_access_key=aConfigObject.m_awsSecKey)
    except:
        msg='Check the AWS Credentials'
        logger.error(msg)
        raise Exception(msg)

    #Validate the SrcBucket/Prefix  for download/ Copy
    if (aConfigObject.m_transfertype=="S3_2_Server" or aConfigObject.m_transfertype=="S3_2_S3"):
        try:       
            assert(ValidateS3Bucket(fs3client,aConfigObject.m_srcbucket,aConfigObject.m_srcPrefix)> 0)
        except:    
            msg='There are no files to download /Copy from Source Bucket or Invalid Bucket'
            logger.error(msg)
            raise Exception(msg)

    #Validate the DestBucket/Prefix  for Upload / Copy
    if (aConfigObject.m_transfertype=="Server_2_S3" or aConfigObject.m_transfertype=="S3_2_S3"):        
        try:       
            ValidateS3Bucket(fs3client,aConfigObject.m_destbucket,aConfigObject.m_destPrefix,False)
        except:
            msg='Invalid Destination Bucket'
            logger.error(msg)
            raise Exception(msg)
    if (aConfigObject.m_transfertype=="Server_2_S3"):
        if not os.path.exists(aConfigObject.m_foldertoupload):
            msg='The src folder does not exists'
            logger.error(msg)
            raise Exception(msg)
        total = 0
        for root, dirs, files in os.walk(aConfigObject.m_foldertoupload):
            total += len(files)
        if (total < 1):
            msg='There are no files in src folder'
            logger.error(msg)
            raise Exception(msg)


def Validate(aArgs,aAppConfigObject):
    fconfigfolder=aAppConfigObject.configFolder
    fConfigFile= os.path.join(fconfigfolder, args.ConfigFile)
    logger.info("Checking the existence of configuration file")
    if not os.path.exists(fConfigFile):
        msg='Config File is not the path'
        logger.error(msg)
        raise Exception(msg)
    #check if the restore mode is r and check the existence of jsonfile    
    fConfigObj= ConfigObject(fConfigFile,aAppConfigObject.encKey)
    arrvalidTransferTypes=["S3_2_S3" , "S3_2_Server" ,"Server_2_S3"]
    if fConfigObj.m_transfertype not in arrvalidTransferTypes:
        msg='Invalid Transfer Type'
        logger.error(msg)
        raise Exception(msg)
    ValidateFileSystem(fConfigObj)
    folders= [aAppConfigObject.logfolder,aAppConfigObject.rptfolder,aAppConfigObject.metafolder]
    for flder in folders:        
        if not os.path.exists(flder):
            os.makedirs(flder)
    #flagFile= "{}\\{}".format( fconfig.get('FILES', 'FlagFolder'), fconfig.get('FILES', 'FlagFileName'))
    #if os.path.exists(flagFile):
    #    os.remove(flagFile)
    if not aArgs.RefId=="-1" :
        logger.info("Checking the existence of Restored Proces Log json file")        
        Reffile= os.path.join(aAppConfigObject.metafolder, "{}.json".format(aArgs.RefId))
        #"{}\\{}.json".format(fconfig.get('FILES', 'MetaData'),aArgs.RefId )
        if not os.path.exists(Reffile):            
            msg='Metadata File for Restoring not available'
            logger.error(msg)
            raise Exception(msg)    
    #create the folder to download if it does not exist
    logger.info("Configuration Validation Steps Comlpeted successfully")
    pass
if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--ConfigFile', help='Configuration Ini file' , required=True)
    #parser.add_argument('--Mode', help='0-Download 1-Upload 2-S3Copy', required=True)
    #parser.add_argument('--RestoreMode', help='Is is Restore Mode r to restore' , default='n')
    parser.add_argument('--RefId', help='Unique Id for the Restoring',default='-1' )
    args = parser.parse_args()    
    
    logger=None
    fAppConfig=AppConfigObject()
    fUID= str(uuid.uuid1())
    try:
        
        start = time.process_time()        
        logger=Init(fUID,fAppConfig,args.ConfigFile)
        logger.info(args)        
        logger.info("configFile-->"+ args.ConfigFile)        
        logger.info("Unique Id for the Run : "+ fUID)
        logger.info("Start Time "+time.strftime('%X %x %Z') )        
        logger.info("Configuration Validation Steps Starts")
        Validate(args,fAppConfig)
        logger.info("Configuration Validation Completed")
        asyncio.run(ExecuteMain(fAppConfig,args,fUID))
    except KeyboardInterrupt:
        logger.error("captured ctrl cancel from Main")
    except: 
        logger.error("error occurred")
        logger.error(print_exc(),exc_info=1)        
    finally:
        pass    
    logger.info("End Time "+time.strftime('%X %x %Z') )    
    