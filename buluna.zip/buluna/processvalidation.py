import boto3
from boto3.s3 import transfer
import os
from shutil import copyfile
import logging
import datetime
import pandas as pd
from utils import AppConfigObject,ConfigObject,s3SupportObject,TransferInfo
class ProcessValidator(object):
    def __init__(self,appConfigObject,aConfigObject,aS3SupportObject):        
        self.m_appConfigObj=appConfigObject        
        self.m_ConfigObject=aConfigObject
        self.m_supportObject=aS3SupportObject 
        self.m_logger=logging.getLogger('S3UtilLogger')
        self.m_reportFileName=""
        self.m_excpreportFileName=""
    def ValidateFiles(self,arrTransferInfo):
            self.m_logger.info("Creating html report File Validation")
            fRptFolder=self.m_appConfigObj.rptfolder
            utc_datetime = datetime.datetime.utcnow()
            rptfile="qa_rpt_"+ utc_datetime.strftime("%Y-%m-%d-%H%MZ")+"_{}".format(self.m_ConfigObject.m_uuid)
            self.m_reportFileName=os.path.join(fRptFolder,  "{}.html".format(rptfile))
            self.m_excpreportFileName=os.path.join(fRptFolder,  "{}_exception.html".format(rptfile))
            dfStats = pd.DataFrame([x.as_dict() for x in arrTransferInfo])
            totalcount= dfStats.shape[0]        
            
            self.m_logger.info("{}{}".format("total # of files  --> ", totalcount ))
            dfStats.to_html(open(self.m_reportFileName, 'w'))
            if (totalcount > 0 ):
                dfStatsExcp=dfStats[dfStats['srcfilesize']!=dfStats['destfilesize']]        
                excCount=dfStatsExcp.shape[0]        
                dfStatsExcp.to_html(open(self.m_excpreportFileName, 'w'))
                if (excCount >0 ):
                    self.m_logger.error("{}{}".format("# of files not satifying File Size Check", excCount ))
                    raise Exception("{}{}".format("# of files not satifying File Size Check", excCount ))
            self.m_logger.info("Creating html report File Validation is completed successfully")
    def UploadReportFile(self):
        arrRptFiles= [self.m_reportFileName,self.m_excpreportFileName]
        if (self.m_ConfigObject.m_transfertype=="Server_2_S3" or self.m_ConfigObject.m_transfertype=="S3_2_S3"):
            if self.m_ConfigObject.m_rptlocation!="":                
                for fRpt in arrRptFiles:
                    if os.path.exists(fRpt):
                        fS3Client= self.m_supportObject.m_arrs3Client[0]
                        tconfig=transfer.TransferConfig(multipart_threshold=5*1024*1024, max_concurrency=5,multipart_chunksize=5*1024*1024, use_threads=True)
                        self.m_logger.info("uploading "+ fRpt  + " Started")
                        fuploadeder = transfer.S3Transfer(fS3Client,tconfig, transfer.OSUtils())
                        fname = os.path.basename(fRpt)
                        fDestFile=self.m_ConfigObject.m_rptlocation+ "/" +fname
                        fuploadeder.upload_file(fRpt,self.m_ConfigObject.m_destbucket,fDestFile)
                        self.m_logger.info("uploading "+ fRpt  + " Completed")        
        elif self.m_ConfigObject.m_transfertype=="S3_2_Server":
            if not os.path.exists(self.m_ConfigObject.m_rptlocation):
                os.makedirs(self.m_ConfigObject.m_rptlocation)
            for fRpt in arrRptFiles:
                if os.path.exists(fRpt):
                    fname = os.path.basename(fRpt)
                    copyfile(fRpt, os.path.join(self.m_ConfigObject.m_rptlocation, fname))
    def CreateFlagFile(self):
        if self.m_ConfigObject.flagFile!="":            
            self.m_logger.info("Creating the Flag File --> "+ self.m_ConfigObject.flagFile  )
            if self.m_ConfigObject.m_transfertype=="S3_2_Server":            
                flagfile=os.path.join(self.m_ConfigObject.m_localfolders,self.m_ConfigObject.flagFile)
                with open(flagfile, 'w') as fp:
                    pass            
            elif (self.m_ConfigObject.m_transfertype=="Server_2_S3" or self.m_ConfigObject.m_transfertype=="S3_2_S3"):
                fdata = b''
                fS3Client= self.m_supportObject.m_arrs3clientres[0]
                fKeyName=self.m_ConfigObject.m_destPrefix+ "/"+self.m_ConfigObject.flagFile
                fobject = fS3Client.Object(self.m_ConfigObject.m_destbucket, fKeyName)
                fobject.put(Body=fdata)                
            self.m_logger.info("creation of flag file "+ self.m_ConfigObject.flagFile  + " is Completed")