import boto3
import os
import logging
from utils import LockOb,BoundedExecutor,AppConfigObject,ConfigObject,s3SupportObject,TransferInfo
class ConfigValidator(object):
    def __init__(self,aArgs,aAppConfigObject):
        self.m_Args=aArgs
        self.m_appConfigObj=aAppConfigObject
        self.m_ConfigObject=None
        self.m_logger=logging.getLogger('S3UtilLogger')
    def ValidateS3Bucket(self,aS3Client,aBucket, aPrefix,aCountCheck=True):
            fcnt=0
            fkeys = []
            fnext_token = ''        
            fPrefixtmp=aPrefix.split(",")
            fPrefix=fPrefixtmp[0]
            base_kwargs = {'Bucket': aBucket, 'Prefix': fPrefix }
            while fnext_token is not None :
                kwargs = base_kwargs.copy()
                if fnext_token != '':
                    kwargs.update({'ContinuationToken': fnext_token})
                results = aS3Client.list_objects_v2(**kwargs)
                contents = results.get('Contents')
                if  aCountCheck==False:
                    return 1
                for i in contents:
                    k = i.get('Key')
                    if k[-1] != '/':
                        fkeys.append(k)
                        fcnt+=1
                    if fcnt> 0:
                        break
                fnext_token = results.get('NextContinuationToken')
            return fcnt

    def ValidateFileSystem(self):
        
        fs3client=None
        try:       
            fs3client = boto3.client('s3', aws_access_key_id=self.m_ConfigObject.m_awsAccKey,aws_secret_access_key=self.m_ConfigObject.m_awsSecKey)
        except:
            msg='Check the AWS Credentials'
            self.m_logger.error(msg)
            raise Exception(msg)

        #Validate the SrcBucket/Prefix  for download/ Copy
        if (self.m_ConfigObject.m_transfertype=="S3_2_Server" or self.m_ConfigObject.m_transfertype=="S3_2_S3"):
            try:       
                assert(self.ValidateS3Bucket(fs3client,self.m_ConfigObject.m_srcbucket,self.m_ConfigObject.m_srcPrefix)> 0)
            except:    
                msg='There are no files to download /Copy from Source Bucket or Invalid Bucket'
                self.m_logger.error(msg)
                raise Exception(msg)

        #Validate the DestBucket/Prefix  for Upload / Copy
        if (self.m_ConfigObject.m_transfertype=="Server_2_S3" or self.m_ConfigObject.m_transfertype=="S3_2_S3"):        
            try:       
                self.ValidateS3Bucket(fs3client,self.m_ConfigObject.m_destbucket,self.m_ConfigObject.m_destPrefix,False)
            except:
                msg='Invalid Destination Bucket'
                self.m_logger.error(msg)
                raise Exception(msg)
        if (self.m_ConfigObject.m_transfertype=="Server_2_S3"):
            if not os.path.exists(self.m_ConfigObject.m_foldertoupload):
                msg='The src folder does not exists'
                self.m_logger.error(msg)
                raise Exception(msg)
            total = 0
            for root, dirs, files in os.walk(self.m_ConfigObject.m_foldertoupload):
                total += len(files)
            if (total < 1):
                msg='There are no files in src folder'
                self.m_logger.error(msg)
                raise Exception(msg)


    def Validate(self):
        fconfigfolder=self.m_appConfigObj.configFolder
        fConfigFile= os.path.join(fconfigfolder, self.m_Args.ConfigFile)
        self.m_logger.info("Checking the existence of configuration file")
        if not os.path.exists(fConfigFile):
            msg='Config File is not the path'
            self.m_logger.error(msg)
            raise Exception(msg)
        #check if the restore mode is r and check the existence of jsonfile    
        fConfigObj= ConfigObject(fConfigFile,self.m_appConfigObj.encKey)
        arrvalidTransferTypes=["S3_2_S3" , "S3_2_Server" ,"Server_2_S3"]
        if fConfigObj.m_transfertype not in arrvalidTransferTypes:
            msg='Invalid Transfer Type'
            self.m_logger.error(msg)
            raise Exception(msg)
        self.m_ConfigObject= fConfigObj
        self.ValidateFileSystem()
        folders= [self.m_appConfigObj.logfolder,self.m_appConfigObj.rptfolder,self.m_appConfigObj.metafolder]
        for flder in folders:        
            if not os.path.exists(flder):
                os.makedirs(flder)
        #flagFile= "{}\\{}".format( fconfig.get('FILES', 'FlagFolder'), fconfig.get('FILES', 'FlagFileName'))
        #if os.path.exists(flagFile):
        #    os.remove(flagFile)
        if not self.m_Args.RefId=="-1" :
            self.m_logger.info("Checking the existence of Restored Proces Log json file")        
            Reffile= os.path.join(self.m_appConfigObj.metafolder, "{}.json".format(self.m_Args.RefId))
            #"{}\\{}.json".format(fconfig.get('FILES', 'MetaData'),aArgs.RefId )
            if not os.path.exists(Reffile):            
                msg='Metadata File for Restoring not available'
                self.m_logger.error(msg)
                raise Exception(msg)    
        #create the folder to download if it does not exist
        self.m_logger.info("Configuration Validation Steps Comlpeted successfully")
        pass