from __future__ import division, print_function
import argparse
import collections
import functools
import os
import boto3
import sys
import threading
import configparser
import time
import pandas as pd
from boto3.s3 import transfer
import threading
from concurrent import futures
import signal
import concurrent.futures
import numpy
import asyncio
from traceback import print_exc
import logging
import datetime
import re
from threading import BoundedSemaphore
from utils import LockOb,BoundedExecutor,AppConfigObject,ConfigObject,s3SupportObject,TransferInfo
from processvalidation import ProcessValidator


class ParallelBaseExecutor:
    def __init__(self,aConfigObject,aAppConfigObject):
        self.m_appConfigObject=aAppConfigObject 
        self.m_ConfigObject=aConfigObject
        self.m_arrTransferInfo=[]
        self.ms3SupportObject= s3SupportObject(aConfigObject)
        self.m_lockobj=None
        self.m_logger=logging.getLogger('S3UtilLogger')
    def ExportWorkLoad(self,arrayWorkLoad=None):
        if (arrayWorkLoad==None):
           arrayWorkLoad=self.m_arrTransferInfo
        df1 = pd.DataFrame([x.as_dict_v2() for x in self.m_arrTransferInfo])        
        exportfilename=os.path.join(self.m_appConfigObject.metafolder,"{}.json".format(self.m_ConfigObject.m_uuid ))
        df1.to_json(exportfilename, orient='records')

    def GetArrayWorkloadfromDict(self,aDictTrans):
        fArrTransInfofromDF=[]
        for key in aDictTrans:
            fTransInfo= TransferInfo.GetTransInfo(key)
            fArrTransInfofromDF.append(fTransInfo)
        return fArrTransInfofromDF
    def LoadWorkLoad(self,aUUID):
        wfile=os.path.join(self.m_appConfigObject.metafolder,"{}.json".format(aUUID))
        df2 = pd.read_json(wfile, orient='records')
        dicTInforecords = df2.to_dict('records')
        farrTransInfofromDF=self.GetArrayWorkloadfromDict(dicTInforecords)
        if farrTransInfofromDF!=None:
            self.m_arrTransferInfo=farrTransInfofromDF
        return 
    def UpdateTask(self,dicTInforecords,aKey):        
        fTranInfo= next((x for x in dicTInforecords if x.Id == aKey), None)
        fTranInfo.m_status=1

    def MarkATaskCompleted(self,aUUID, aKey):
        with self.m_lockobj.m_lock:
            self.ExportWorkLoad()
    def MatchPattern(self,aFileName):
        fRet=False        
        if (re.match(self.m_ConfigObject.regpattern, aFileName,re.I)!=None ):            
            return True
        return fRet
    def preparefilelist(self):
        return self.m_arrTransferInfo
    def createSuccessfile(self):        
        flagfile=os.path.join(self.m_ConfigObject.m_localfolders,self.m_ConfigObject.flagFile)
        with open(flagfile, 'w') as fp:
            self.m_logger.info("Created Flag file")
    def MoveRptandSuccessfiletoS3(self):
        pass    
    async def ExecuteParallel(self,aUUID=None):
        executor=None
        pStatus=True
        try:
            executor = BoundedExecutor(self.m_ConfigObject.m_numthreads)
            for fTransferInfo in self.m_arrTransferInfo:
                executor.submit(self.Execute, fTransferInfo)
        except KeyboardInterrupt:
            pStatus=False            
            raise
        except: 
            pStatus=False        
            raise
        finally:            
            if (executor!=None):
                executor.shutdown(pStatus)            
    
    async def ExecuteParallelB(self,aUUID=None):
        try:        
            with concurrent.futures.ThreadPoolExecutor(max_workers=self.m_ConfigObject.m_numthreads) as executor:
                future_results=[]            
                for fTransferInfo in self.m_arrTransferInfo:                
                    with self.m_lockobj.m_lock:
                        if self.m_lockobj.m_cancel==True:
                            break                    
                    future_result=executor.submit(self.Execute, fTransferInfo)
                    future_results.append(future_result)
                concurrent.futures.wait(future_results)
        except KeyboardInterrupt:
            self.m_logger.info("captured ctrl cancel from ExecuteParallel")
            with self.m_lockobj.m_lock:
                self.m_lockobj.m_cancel=True
            raise

    def Execute(self,aTransferInfo):        
        copy_source = {'Bucket': aTransferInfo.m_srcbucket,'Key': aTransferInfo.m_srckey}
        fS3ClientRes= self.ms3SupportObject.m_arrs3clientres[aTransferInfo.m_s3resId]
        fS3ClientRes.m_s3res.meta.client.copy(copy_source, aTransferInfo.m_destbucket, aTransferInfo.m_destkey)


    def postprocess(self): 
        try:
            fProcessValidator =ProcessValidator(self.m_appConfigObject,self.m_ConfigObject,self.ms3SupportObject)
            fProcessValidator.ValidateFiles(self.m_arrTransferInfo)
            fProcessValidator.UploadReportFile()
            fProcessValidator.CreateFlagFile()
        except:
            self.m_logger.error("Error occurred during postprocess")
            self.m_logger.error(print_exc(),exc_info=1)    
        
    def __exit__(self, exc_type, exc_val, exc_tb):
        self.m_logger.info('Exit from ParallelExecutor')
        self.finalize()

    def __enter__(self):
        self.m_logger.info('enter into ParallelExecutor')
        return self